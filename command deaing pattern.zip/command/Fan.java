package command;

public class Fan implements IOT{
    public void on(){
        System.out.println("the fan is on");
    }

    public void off(){
        System.out.println("the fan is off!");
    }
}
